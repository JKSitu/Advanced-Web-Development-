<template>
      <h1>To-Do</h1>
        <form @submit.prevent="addItem">
            <label for="taskInput">Task:</label>
            <input name="taskInput" v-model="task"/>
    <br/>
    <br/>
    
    <!--<input name="editTaskInput" v-show="editable" v-model="editTask"/>-->
    <br/>
    <br/>
    <button>Add</button>
  
        </form>
        <ul>
            <li v-for="(item,index) in taskList" :key="index">{{item}} <button v-on:click="deleteItem(index)">Delete</button></li>
            
        </ul>
</template>
<script>
export default{
    data(){
        return{
            task:"",
            taskList:[],
            error:"",
            editTask:"",
            editable:"",
 
        }
    },
    methods:{
        addItem(e){
            if(this.task!==""){
                this.error=""
                this.taskList.push(this.task)
            }
                else{
                    this.error="The task cannot be empty"
                }
            },
            deleteItem(index){
                if(this.taskList[index]){
                    this.error=""
                   delete this.taskList[index]
              
                }
                else{
                    this.error="Something went wrong"
                }
            }
        }
    
}
</script>
