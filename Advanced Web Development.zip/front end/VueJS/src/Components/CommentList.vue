<template>
    <div>
        <h1>Comments</h1>
        <Comment v-for="(comment, index) in comments" :key="index"
        :comment_text="comment.comment_text"
        :author="comment.comment_text"
        :date_published ="comment.date_published"/>
    </div>
</template>


<script>
export default{ 
data() {
    return {
        comments:[
            {comment_text: "I like Vue", author: "Ben", date_published:"14/11/2022"},
            {comment_text: "Me too!", author: "Charles", date_published: "14/11/2022"},
            {comment: "Me three", author: "Dana", date_published: "14/11/2022"} 

        ]
    }
}
}
</script>