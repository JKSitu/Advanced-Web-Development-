<template>
  <div>
    <ul class="nav">
      <li class="nav-item">
        <router-link to="/" class="nav-link">Home</router-link>
      </li>
      <li class="nav-item">
        <router-link to="/login" class="nav-link">Login</router-link>
      </li>
      <li class="nav-item">
        <router-link to="/dashboard" class="nav-link">Dashboard</router-link>
      </li>
    </ul>


    <router-view />
    


  </div>
</template>  




<script>
import ToDo from "./Components/ToDo.vue";
import Login from "./Pages/Login.vue"
import Comment from "./Components/Comment.vue";

  export default{
    data(){
      return {
        welcome_message: "Hello World!", 
        counter: 0
      }
    },
    methods: {
      increment(){
        this.counter ++;
      },

    },
    components:{
      Login,
      ToDo,
      Comment
    }
  }
</script>

<style scoped>

</style>



