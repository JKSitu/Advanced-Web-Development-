<template>
    <h1 class="text-center">Welcome to the Dashboard</h1>
    <div class="container">
        <div v-if="error">
            {{ error }}
        </div>
    <button class="btn btn-warning" v-on:click="logout">Logout</button>
<div class="container">
    <h2>Users:</h2>

    
<table class="table">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Email</th>
        <th scope="col">Firstname</th>
        <th scope="col">Lastname</th>
       
      </tr>
    </thead>
    <tbody>
      <tr v-for="user in users" :key="user.user_id">
        <th scope="row">{{ user.user_id}}</th>
        <td>{{ user.email}}</td>
        <td>{{ user.first_name}}</td>
        <td>{{ user.last_name}}</td>
      
      </tr>
    </tbody>
  </table>
</div>
<div class="container">
    <h2>Add Users:</h2>
    <form @submit.prevent="handleSubmit">
        <div class="mb-3">
            <label for="exampleInputName1" class="form-label">First Name</label>
            <input type="text" class="form-control" id="exampleInputName1" aria-describedby="emailHelp" v-model="firstname">
          </div>
          <div class="mb-3">
            <label for="exampleInputName2" class="form-label">Last Name</label>
            <input type="text" class="form-control" id="exampleInputName2" aria-describedby="emailHelp" v-model="lastname">
          </div>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Email address</label>
          <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" v-model="email">
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Password</label>
          <input type="password" class="form-control" id="exampleInputPassword1" v-model="password">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
</div>

<div class="container">
    <h2>Add article:</h2>
    <form @submit.prevent="handleSubmitArticle">
        <div class="mb-3">
            <label for="exampleInputName1" class="form-label">Author</label>
            <input type="text" class="form-control" id="exampleInputName1" aria-describedby="emailHelp" v-model="authorname">
          </div>
          <div class="mb-3">
            <label for="exampleInputName2" class="form-label">Title</label>
            <input type="text" class="form-control" id="exampleInputName2" aria-describedby="emailHelp" v-model="title">
          </div>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Text</label>
          <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" v-model="text">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
</div>
</div>
</template>
<script>
import {userService} from '../services/user.service'
import { articleService } from '../services/article.service'
export default {
data(){
    return{
        authorname:"",
        title:"",
        text:"",
        firstname:"",
        lastname:"",
        email:"",
        password:"",
        userToken:localStorage.getItem("session_token"),
        users:{}
    }
},
mounted(){
    userService.getAll()
    .then((users=>{
    this.users=users
    }))
    .catch(error =>{
        this.error=error
    })
}
,
    methods: {
        handleSubmit(e) {
        userService.addUser(this.firstname, this.lastname, this.email, this.password, this.userToken)
        .then(id => {
          this.firstname="";
          this.lastname="";
          this.email="";
          this.password="";
         userService.getAll()
        .then((users=>{
        this.users=users
        }))
        .catch(error =>{
        this.error=error
        })
        })
        .catch(error =>{
        this.error=error
        })
        },
        handleSubmitArticle(e) {
        articleService.add(this.authorname, this.title, this.text)
        .then(article=>{this.$router.push('/article/'+article.article_id)})
        .catch(error =>{
        this.error=error
        })
        },
        
        logout() {
            userService.logout()
                .then(this.$router.push('/'))
                .catch(error =>{
        this.error=error
        })


        }
    }
}

</script>