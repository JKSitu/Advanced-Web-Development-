<template>
    <h1  class="text-center">Welcome to the blog</h1>
<ul v-for="article in articles" :key="article.article_id" >
    <div class="card">
        <div class="card-body">
    <router-link :to="'/article/' + article.article_id">
        {{ article.title + ' by ' + article.author }} 
    </router-link>
</div>
</div>
</ul>
</template>

<script>
import { articleService } from "../services/article.service"
export default{
    data(){
        return{
            articles:[],
            error:""
        }
    },
    created(){
articleService.getAll()
.then(article =>{
this.articles=article
})
.catch(error=> this.error=error)

    }
}
</script>

