<template>
    <div class="container">
        <br/>
        <br/>
        <div class="card">
            <div class="card-body">
    <h5>Author: {{ article.author }}</h5>
    <h6>Date Published: {{ article.date_published }}</h6>
    <p>{{ article.article_text }}</p>
</div>
<button class="btn btn-danger" v-on:click="deleteArticle()">delete</button>
</div>
</div>
</template>

<script>  
import { articleService } from "../services/article.service" 
export default {
    
    data(){
        return {
            article_id: this.$route.params.id,
            article:{}
        }
    },
    mounted(){
        articleService.getOne(this.article_id)
        .then(article => {
            this.article=article
        })
        .catch(error=> 
        {this.error=error}
        )
    },
    methods:{
        deleteArticle(){ articleService.deleteArticle(this.article_id)
                .then(this.$router.push('/'))
                .catch(error =>{
        this.error=error})}
    }
}

</script>