<template>
    <div>
      <h1 class="text-center">Login</h1> 
      <form @submit.prevent="handleSubmit" class="container">
          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" v-model="email">
          </div>
          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" v-model="password">
          </div>
          <button type="submit" class="btn btn-primary">Login</button>
        </form>

    </div>
  </template>


<script>
import * as EmailValidator from 'email-validator'
import {userService} from '../services/user.service'
    export default {
      data(){
        return {
          email: "",
          password: "",
          submittedd:false
        }
      },
      methods: {
          handleSubmit(e){
            this.submitted = true
            const {email, password} = this

            if(!(email && password)){
              return;
            }

            if(!(EmailValidator.validate(email))){
              this.error = "Email must be a valid email."
              return;
            }

            const password_pattern = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/
            if(!(password_pattern.test(password))){
              this.error = "Password not strong enough."
              return;
            }
            console.log(email+password);
            userService.login(this.email, this.password)
            .then(()=>{
              this.$router.push('/dashboard')
            })
            .catch(error=> {
              this.error=error
            })
           
          }
      }

    }
</script>


