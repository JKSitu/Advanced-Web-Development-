const login = (email, password) => {
    const data = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            email: email,
            password: password
        })};
    return fetch("http://localhost:3333/login", data)
        .then((resp) => {
            if(resp.status === 200) {
                return resp.json();
            } else if (resp.status === 400) {
                throw "Error - Make sure the information you have entered are correct"
            } else {
                throw "Error - Make sure the information you have entered are correct" 
            }
        })
        .then((resJson) => {
            localStorage.setItem("session_token", resJson.session_token)
            localStorage.setItem("user_id", resJson.user_id)
            return resJson
        })
        .catch((error) => {
            return Promise.reject(error)
        })
}

const addUser = (firstname, lastname, email, password, token) => {
    const data = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': token
        },
        body: JSON.stringify({
            email: email,
            password: password,
            first_name: firstname,
            last_name: lastname
        })
    };
    return fetch("http://localhost:3333/users", data)
        .then((response) => {
            if (response.status === 201) {
                return response.json();
            }else {
                throw "Something went wrong!"
            }
        })
        .then((resJson) => {
            return resJson.user_id;
        })
        .catch((error) => {
            return Promise.reject(error)
        })
}
const getAll = () => {
    const data = {
        headers:{
            'Content-Type': 'application/json',
            'X-Authorization': localStorage.getItem("session_token")
        }
    }
    return fetch ("http://localhost:3333/users", data)
        .then ((resp) => {
            if (resp.status === 200) {
                return resp.json();
            } else {
                throw "error happened"
            }
        })
        .then((resJson) => {
            return resJson
        })
        .catch((error) => {
            console.log(error)
            return Promise.reject(error)
        })
}
const logout = () => {
    const data = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': localStorage.getItem("session_token")
        }
    };
    return fetch("http://localhost:3333/logout", data)
        .then((response) => {
            if (response.status === 200) {
                localStorage.removeItem("user_id")
                localStorage.removeItem("session_token")
                return
            } else {
                throw "Something went wrong"
            }
        })
        .catch((error) => {
            return Promise.reject(error)
        })
}



export const userService = {
    login:login,
    getAll:getAll,
    addUser:addUser,
    logout:logout,
    
}