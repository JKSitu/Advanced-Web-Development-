const getAll = () => {
    return fetch("http://localhost:3333/articles")
    .then((response) => {
        if(response.status === 200){
            return response.json();
        }else{
            throw "something went wrong" 
        }

    })
    .then((resJson) => {
        return resJson
    })
    .catch((error) => {
        console.log("Err", error)
        return Promise.reject(error)
    })
}

const getOne = (id) =>{
    return fetch("http://localhost:3333/articles/"+id)
    .then((resp)=>{
        if(resp.status===200){
            return resp.json();
        }
        else{
            throw "there is an error"
        }
    })
    .then((resJson)=>{
        return resJson
    })
    .catch((error)=>{
        console.log(error)
        return Promise.reject(error)
    })
}

const add = (authorname, title, text) => {
    const data = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': localStorage.getItem("session_token")
        },
        body: JSON.stringify({
            "author": authorname,
            "title": title,
            "article_text": text
        })
    }
    return fetch("http://localhost:3333/articles/", data)
        .then((response) => {
            if (response.status === 201) {
                return response.json();
            }
            else{
                throw "Something went wrong"
            }
        })
        .then((resJson) => {
            return resJson
        })
        .catch((error) => {
            return Promise.reject(error)
        })
}

const deleteArticle = (id) => {
    const data = {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': localStorage.getItem("session_token")
        },
        
    };
    return fetch("http://localhost:3333/articles/"+id, data)
        .then((response) => {
            if (response.status === 200) {
                return
            } else {
                throw "Something went wrong"
            }
        })
        .catch((error) => {
            return Promise.reject(error)
        })
}

export const articleService = {
    getAll,
    getOne,
    add,
    deleteArticle
}