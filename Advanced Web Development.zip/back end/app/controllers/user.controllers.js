const models =require('../models/user.models')
const joi = require('joi')


const getUsers = (req,res) =>{
    models.getUsers((err, num_rows, allUsers)=>{
        if(err){
            return res.sendStatus(500)
        }
            return res.status(200).send(allUsers);
        
    })

}
const addUser = (req,res) =>{
     const schema = joi.object({
        "first_name": joi.string().required(),
        "last_name" :joi.string().required(),
    "email": joi.string().email().required(),
"password": joi.string().min(8).max(12).required()  
}) 
const {error}= schema.validate(req.body);
if(error) {
    return res.status(400).send(error.details[0].message)
}
let newUser= Object.assign({}, req.body)
models.addUser(newUser,(err,id)=>{
    if(err){
        return res.sendStatus(500)
    }
    return res.status(201).send({user_id:id})
})
}

const login =(req,res) =>{
const schema  =joi.object({
    "email":joi.string().email().required(),
    "password":joi.string().required()
})
const {error}= schema.validate(req.body);
if(error) {
    return res.status(400).send(error.details[0].message)
}
let email= req.body.email;
let password= req.body.password;

models.authenticateUser(email, password, (err,id) =>{
    if(err===404){
        return res.status(400).send("You have entered an invalid email or paassword")
    }
    if(err)return res.sendStatus(500)
    
    models.getToken(id, (err,token)=>{
        if(err)return res.sendStatus(500)
        if(token){
            return res.status(200).send({user_id:id,session_token:token})
        }
        else{
            models.setToken(id,(err,token)=>{
                if(err)return res.sendStatus(500)
                return res.status(200).send({user_id:id, session_token:token})
            })
        }
    })
})
}

const logout = (req,res) =>{
let token = req.get('X-Authorization');
models.removeToken(token, (err)=>{
    if(err)return res.sendStatus(500)
    return res.sendStatus(200)
})
}

module.exports ={
    addUser:addUser,
    login:login,
    logout:logout,
    getUsers:getUsers
}